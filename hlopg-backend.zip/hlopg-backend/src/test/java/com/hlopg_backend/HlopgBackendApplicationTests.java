package com.hlopg_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HlopgBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
